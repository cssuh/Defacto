module.exports = {
    SMMRY : "0D57C7F0C6",
    Google_Custom_Search: "AIzaSyBDxGUwAq1nfCEbTjchDpw4zcqSK_36G1U"
}