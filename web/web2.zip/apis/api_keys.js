module.exports = {
    SMMRY : "0D57C7F0C6",
    Google_Custom_Search: "AIzaSyBDxGUwAq1nfCEbTjchDpw4zcqSK_36G1U",
    Microsoft_Cognitive_Text_Analytics : "056b74740ae04950aa414fa6b3d5ee79"
}